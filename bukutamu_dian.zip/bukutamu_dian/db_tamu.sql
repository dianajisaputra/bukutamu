-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 29 Feb 2024 pada 03.25
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_tamu`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE `login` (
  `no` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `pass` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `login`
--

INSERT INTO `login` (`no`, `user`, `pass`) VALUES
(0, 'mis@gmail.com', '12345'),
(0, 'dianas', '1234'),
(0, 'dian aji saputra', 'kata sandi12345');

-- --------------------------------------------------------

--
-- Struktur dari tabel `siswa2`
--

CREATE TABLE `siswa2` (
  `no` int(11) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jk` varchar(25) NOT NULL,
  `alamat` text NOT NULL,
  `keperluan` varchar(30) NOT NULL,
  `nohp` varchar(25) NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `siswa2`
--

INSERT INTO `siswa2` (`no`, `nama`, `jk`, `alamat`, `keperluan`, `nohp`, `waktu`) VALUES
(61, 'dian aji saputra', '2 orang', 'kp.sindangpalay', 'pindahan', '083********5', '2024-02-29 01:20:03'),
(66, 'toto', '2 orang', 'teuing timana', 'pindah', '083********4', '2024-02-29 01:34:54'),
(68, 'cecep', '2 orang', 'kp.mana', 'pendatang', '083********9', '2024-02-26 02:24:40'),
(69, 'cecep', '2 orang', 'teuing timana', 'pindahan', '083********3', '2024-02-26 04:49:13'),
(72, 'trt rth', 'sen3', 'kp jauh', 'naon', '345565', '2024-02-29 01:19:41'),
(73, 'missss', 'sen3', 'kp jauh', 'naon', 'llll', '2024-02-29 01:40:07'),
(74, 'trt rth', 'sen3', 'kp.sindangpalay', 'naon', '345565', '2024-02-29 01:40:33'),
(75, 'dian aji saputra', 'sen3', 'kp.sindangpalay', 'naon', '34356567', '2024-02-29 01:56:31');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `siswa2`
--
ALTER TABLE `siswa2`
  ADD PRIMARY KEY (`no`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `siswa2`
--
ALTER TABLE `siswa2`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
