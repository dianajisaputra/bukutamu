<?php
include "koneksi.php";
include "boot.php";
include "section.php";

$id = $_GET['id'];
$panggil = $konek->query("SELECT * FROM siswa2 WHERE no='$id'");
$a = $panggil->fetch_array();

if (isset($_POST['edit'])) {
  $ubah = $konek->query("UPDATE siswa2 SET nama='$_POST[nama]', jk='$_POST[jk]', alamat='$_POST[alamat]', keperluan='$_POST[keperluan]', nohp='$_POST[nohp]' WHERE no='$id'");
  if ($ubah) {
    echo "<script>alert('Data berhasil diubah');</script>";
  }
}
?>

<div class="container col-5">
  <form class="form-control mt-3 bg-info text-light" action="" method="post">
    <div class="mb-3">
      <label for="exampleInputEmail1" class="form-label"><b><i>Nama</b></i></label>
      <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="nama" value="<?= $a['nama'] ?>" >

      <label for="exampleInputEmail1" class="form-label"><b><i>Anggota Keluarga</b></i></label>
      <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="jk" value="<?= $a['jk'] ?>" >

      <label for="exampleInputEmail1" class="form-label"><b><i>Alamat</b></i></label>
      <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="alamat" value="<?= $a['alamat'] ?>" >

      <label for="exampleInputEmail1" class="form-label"><b><i>Keperluan</b></i></label>
      <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="keperluan" value="<?= $a['keperluan'] ?>" >

      <label for="exampleInputEmail1" class="form-label"><b><i>No HP</b></i></label>
      <input type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="nohp" value="<?= $a['nohp'] ?>" >
    </div>
    <div class="d-flex justify-content-between">
      <div class="">
        <button type="submit" class="btn btn-warning mt-2 mb-3" name="edit">Simpan</button>
      </div>

      <div class="">
        <button type="submit" class="btn btn-warning mt-2 mb-3"><a href='tampil.php'>Kembali</a></button>
      </div>
    </div>
  </form>
</div>
