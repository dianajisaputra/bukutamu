
<?php
include "boot.php";
include "koneksi.php";
include "section.php";

$searchTerm = isset($_GET['q']) ? $_GET['q'] : '';
$dateFilter = isset($_GET['date']) ? $_GET['date'] : ''; // Mengambil nilai filter tanggal dari parameter URL

// Membuat kondisi tambahan pada query SQL untuk filter tanggal jika parameter date ada
$dateCondition = '';
if (!empty($dateFilter)) {
  $dateCondition = "AND DATE(waktu) = '$dateFilter'";
}

$tampil = "SELECT * FROM siswa2 WHERE nama LIKE '%$searchTerm%' $dateCondition ORDER BY waktu DESC"; // Mengurutkan data berdasarkan waktu DESC

$result = $konek->query($tampil);
?>

<div class="text-end">
      <button class="btn" onclick="printDiv('div1')"><i class="bi bi-printer-fill fs-1 "></i></button>
    </div>

    <form action="" method="GET" class="mb-3">
      <div class="input-group">
        <input type="date" class="form-control" placeholder="Filter tanggal (YYYY-MM-DD)" aria-label="Filter tanggal" name="date">
        <button class="btn btn-outline-secondary" type="submit">Cari</button>
      </div>
    </form>

    <div id="div1">

<div class="">
  <div class="text-center">
    <h3><b><i>Rekapan Data</i></b></h3>
  </div>


    <!-- tampil -->
    <table class="table table-dark table-striped">
      <thead class="table-dark">
        <tr>
          <th scope="col">no</th>
          <th scope="col">Nama</th>
          <th scope="col">Anggota Keluarga</th>
          <th scope="col">Alamat</th>
          <th scope="col">Keperluan</th>
          <th scope="col">Nomor Hp</th>
          <th scope="col">Waktu</th>
          <th scope="col"></th>
        </tr>
      </thead>
      <tbody>
        <?php
        $no = 0;
        while ($s = $result->fetch_assoc()) {
          $no++;
        ?>
          <tr>
            <th scope="row"><?= $no; ?></th>
            <td><?= $s['nama'] ?></td>
            <td><?= $s['jk'] ?></td>
            <td><?= $s['alamat'] ?></td>
            <td><?= $s['keperluan'] ?></td>
            <td><?= $s['nohp'] ?></td>
            <td><?= $s['waktu'] ?></td>
            <td>
            </td>
          </tr>
        <?php
        }
        ?>
      </tbody>
    </table>
    <!-- tutup tampil -->
  </div>
</div>

<script>
  function printDiv(el) {
    var a = document.body.innerHTML;
    var b = document.getElementById(el).innerHTML;
    document.body.innerHTML = b;
    window.print();
    document.body.innerHTML = a;
  }
</script>
