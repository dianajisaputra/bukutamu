<?php
include "boot.php";
$date = date('Y-m-d');
?>

<div class="row">
    <div class="col">
        <a href="tampil.php?filter=hari_ini" class="btn btn-dark">
            <div class="card" style="width: 12rem;">
                <img src="../img/hhh.png" class="card-img-top" alt="...">
                <div class="card-body">
                    <p class="card-text">Tamu Hari Ini : </p>
                    <?php
                    include "koneksi.php";
                    $lihat = $konek->query("SELECT waktu FROM siswa2 WHERE DATE(waktu) = CURDATE()");
                    $jumlah = $lihat->num_rows;
                    echo "<strong>$jumlah</strong>";
                    ?>
                </div>
            </div>
        </a>
    </div>

    <div class="col">
        <a href="tampil.php?filter=bulan_ini" class="btn btn-dark">
            <div class="card" style="width: 12rem;">
                <img src="../img/hhh.png" class="card-img-top" alt="...">
                <div class="card-body">
                    <p class="card-text">Tamu Bulan ini : </p>
                    <?php
                    include "koneksi.php";
                    $lihat = $konek->query("SELECT waktu FROM siswa2 WHERE DATE_FORMAT(waktu,'%Y-%m') = DATE_FORMAT(CURDATE(),'%Y-%m')");
                    $jumlah = $lihat->num_rows;
                    echo "<strong>$jumlah</strong>";
                    ?>
                </div>
            </div>
        </a>
    </div>

    <div class="col">
        <a href="tampil.php?filter=tahun_ini" class="btn btn-dark">
            <div class="card" style="width: 12rem;">
                <img src="../img/hhh.png" class="card-img-top" alt="...">
                <div class="card-body">
                    <p class="card-text">Tamu Tahun ini : </p>
                    <?php
                    include "koneksi.php";
                    $lihat = $konek->query("SELECT waktu FROM siswa2 WHERE YEAR(waktu) = YEAR(CURDATE())");
                    $jumlah = $lihat->num_rows;
                    echo "<strong>$jumlah</strong>";
                    ?>
                </div>
            </div>
        </a>
    </div>
</div>
