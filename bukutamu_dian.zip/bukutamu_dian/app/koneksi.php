<?php
$konek=new mysqli ("localhost","root","","db_tamu")
?>