<?php
session_start();
$user = $_SESSION['user'];

if ($user == "") {
  // Jika user belum login, arahkan ke halaman index.php
  echo "<script>document.location = '../index.php';</script>";
} else {
  include "boot.php";
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>12RPL2_DIANAS</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand text-warning" href="#"><i><i class="bi bi-journals"></i><b> BUKU TAMU WARGA</b></i></a>
    <form class="d-flex" role="search" method="GET" action="tampil.php" target="konten">
      <input class="form-control me-2" type="search" name="q" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success" type="submit">Cari</button>
    </form>
  </div>
</nav>
<!-- End Navbar -->

<div class="container mt-4">
  <div class="row">
    <!-- Sidebar -->
    <div class="list-group col-2">
      <a href="dash.php" target="konten" class="list-group-item list-group-item-action list-group-item-success"><b>Dasboard</b></a>
      <a href="input.php" target="konten" class="list-group-item list-group-item-action list-group-item-dark"><b>Input Data</b></a>
      <a href="tampil.php" target="konten" class="list-group-item list-group-item-action list-group-item-warning"><b>Data Tamu</b></a>
      <a href="rekap.php" target="konten" class="list-group-item list-group-item-action list-group-item-info"><b>Rekap</b></a>
      <!-- Tambahkan konfirmasi saat tombol "Logout" diklik -->
      <a href="#" onclick="confirmLogout()" class="list-group-item list-group-item-action list-group-item-danger"><b>Logout</b></a>
    </div>
    <!-- End Sidebar -->

    <!-- Content -->
    <div class="col">
      <iframe src="dash.php" name="konten" frameborder="0" width="100%" height="800"></iframe>
    </div>
    <!-- End Content -->
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

<script>
  // Function untuk menampilkan konfirmasi saat tombol "Logout" diklik
  function confirmLogout() {
    var logout = confirm("Apakah Anda yakin ingin logout?");
    if (logout) {
      // Jika user menekan tombol "OK" pada konfirmasi, arahkan ke halaman logout.php
      window.location.href = "logout.php";
    }
  }
</script>

</body>
</html>

<?php
}
?>
