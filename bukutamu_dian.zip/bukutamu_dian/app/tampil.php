<?php
include "boot.php";
include "koneksi.php";
include "section.php";

$searchTerm = isset($_GET['q']) ? $_GET['q'] : '';

$tampil = "SELECT * FROM siswa2 WHERE nama LIKE '%$searchTerm%' ORDER BY no DESC"; // Menambahkan pengurutan data berdasarkan nomor DESC untuk menampilkan data terbaru di atas

$result = $konek->query($tampil);
?>
<div class="">
  <div calass="roow">
    <div class="">
      <div class="text-center">
        <h3><b><i>Data Tamu</i></b></h3>
      </div>
      <table class="table table-dark table-striped">
        <thead class="table-dark">
          <tr>
            <th scope="col">no</th>
            <th scope="col">Nama</th>
            <th scope="col">Anggota Keluarga</th>
            <th scope="col">Alamat</th>
            <th scope="col">Keperluan</th>
            <th scope="col">Nomor hp</th>
            <th scope="col">Waktu</th>
            <th scope="col">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $no = 0;
          while ($s = $result->fetch_assoc()) {
            $no++;
          ?>
            <tr>
              <th scope="row"><?= $no; ?></th>
              <td><?= $s['nama'] ?></td>
              <td><?= $s['jk'] ?></td>
              <td><?= $s['alamat'] ?></td>
              <td><?= $s['keperluan'] ?></td>
              <td><?= $s['nohp'] ?></td>
              <td><?= $s['waktu'] ?></td>
              <td>
                <button class="btn btn-danger" onclick="confirmDelete(<?= $s['no'] ?>)"><i class="bi bi-trash3-fill"></i></button>
                <button class="btn btn-primary" onclick="document.location.href='update.php?id=<?= $s['no'] ?>'"><i class="bi bi-pencil-square"></i></button>
              </td>
            </tr>
          <?php
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
  function confirmDelete(id) {
    if (confirm('Anda yakin ingin menghapus?')) {
      window.location.href = 'hapus.php?id=' + id;
    }
  }
</script>
