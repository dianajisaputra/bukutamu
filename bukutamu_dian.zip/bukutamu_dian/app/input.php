<?php
include "boot.php";
?>
<div class="container">
  <div class="row">
    <div class="text-center">
      <h3><b><i>Masukan Data Tamu</i></b></h3>
    </div>

    <div class="">
      <form class="form-control mt-3 bg-warning text-dark" action="prosesinput.php" method="post" id="formInput">
        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label"><b><i>Nama</i></b></label>
          <input type="text" class="form-control" id="formGroupExampleInput" aria-describedby="emailHelp" name="nama" required>
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput2" class="form-label"><b><i>Anggota Keluarga</i></b></label>
          <input type="text" class="form-control" id="formGroupExampleInput2" aria-describedby="emailHelp" name="jk" required>
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput2" class="form-label"><b><i>Alamat</i></b></label>
          <input type="text" class="form-control" id="formGroupExampleInput2" aria-describedby="emailHelp" name="alamat" required>
        </div>
        <div class="mb-3">
          <label for="formGroupExampleInput2" class="form-label"><b><i>Keperluan</i></b></label>
          <input type="text" class="form-control" id="formGroupExampleInput2" aria-describedby="emailHelp" name="keperluan" required>
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput2" class="form-label"><b><i>No Hp</i></b></label>
          <input type="number" class="form-control" id="formGroupExampleInput2" aria-describedby="emailHelp" name="nohp" required>
        </div>

        <div class="text-end">
          <button type="submit" class="btn btn-dark mt-2 mb-2S" id="submitForm"><b>Simpan</b></button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
  document.getElementById('formInput').addEventListener('submit', function(event) {
    event.preventDefault(); // Mencegah form untuk melakukan submit default

    // Menampilkan notifikasi
    alert('Data berhasil disimpan!');

    // Melakukan submit form secara manual
    document.getElementById('formInput').submit();
  });
</script>
